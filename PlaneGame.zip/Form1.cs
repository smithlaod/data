﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PlaneGame
{
    public partial class PlaneGame : Form
    {
        
        public PlaneGame()
        {
            InitializeComponent();
            init();
        }

        private void init() {
            SingleFactory.GetSingle().AddObject(new Background(0, -360, 5));
            SingleFactory.GetSingle().AddObject(new Hero(100, 200, Direction.UP, 3, 3));

            List<LittleEnemyPlane> littleEnemies = new List<LittleEnemyPlane>();
            List<BigEnemyPlane> bigEnemies = new List<BigEnemyPlane>();

            for (int i = 0; i < 10; i++) {
                int x = (25 * i) % 400;
                int y = (-40 * i);
                littleEnemies.Add(new LittleEnemyPlane(x, y, Direction.DOWN));
            }
            SingleFactory.GetSingle().AddObject(littleEnemies);
            for (int i = 0; i < 5; i++)
            {
                int x = (90 * i) % 400;
                int y = (200 * i - 700);
                bigEnemies.Add(new BigEnemyPlane(x, y, Direction.DOWN));
            }
            SingleFactory.GetSingle().AddObject(bigEnemies);
        }

        private void PlaneGame_Paint(object sender, PaintEventArgs e)
        {
            SingleFactory.GetSingle().Draw(e.Graphics);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        private void PlaneGame_Load(object sender, EventArgs e)
        {
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint
                    | ControlStyles.ResizeRedraw, true);
        }

        private void PlaneGame_MouseMove(object sender, MouseEventArgs e)
        {
            SingleFactory.GetSingle().hero.mouseMove(e);
            Cursor.Hide();
        }

        private void PlaneGame_MouseClick(object sender, MouseEventArgs e)
        {
            SingleFactory.GetSingle().Shoot();
        }

        /// <summary>
        /// 按键操作测试
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void PlaneGame_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 74) {
                MessageBox.Show("dssadsadsad");
            }
        }
    }
}
