﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PlaneGame.Properties;

namespace PlaneGame
{
    class Hero : PlaneFather
    {
        private static Image[] ImgHero = { Resources.hero1,Resources.hero2 };
        static int num = 0;

        public Hero(int x, int y, Direction dir, int speed, int life) : base(x, y, Resources.hero1.Width, Resources.hero1.Height
                , dir, speed, life) {
        }
        public override void Draw(Graphics g)
        {
            int index = num++ > 10 ? 0 : 1;
            num = num > 20 ? 0 : num;
            g.DrawImage(ImgHero[index], X, Y, ImgHero[index].Width / 2, ImgHero[index].Height / 2);
        }

        public void mouseMove(MouseEventArgs e) {
            this.X = e.X > max_width - this.Width/2 ? max_width - this.Width/2 : e.X;
            this.Y = max_height - e.Y > this.Height / 2 ? e.Y : max_height - this.Height / 2;
        }
    }
}
