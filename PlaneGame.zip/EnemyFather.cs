﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlaneGame
{
    abstract class EnemyFather : PlaneFather
    {
        public int index = 0;
        public Image enemyPlane;
        public bool isDead { set; get; }
        public bool shouldBeNull { set; get; }
        public bool isOut { set; get; }
        public List<Image> MoveAnima;
        public List<Image> DieAnima;
        public List<Image> HitAnima;
        public EnemyFather(/*Dictionary<string, List<Image>> animation,*/
                Func<Dictionary<string, List<Image>>> func, Image enemy, int x, int y, Direction dir, int speed, int life)
            : base (x, y, enemy.Width, enemy.Height, dir, life, speed)
        {
            Dictionary<string, List<Image>> animation = func();
            if (animation != null) {
                if(animation.ContainsKey("die") )
                    DieAnima = animation["die"];
                if(animation.ContainsKey("move"))
                    MoveAnima = animation["move"];
                if(animation.ContainsKey("getHit"))
                    HitAnima = animation["getHit"];
            }
            enemyPlane = enemy;
            isDead = false;
            isOut = false;
            shouldBeNull = false;
        }

        // TODO 设计花式运动的敌人

    }
}
