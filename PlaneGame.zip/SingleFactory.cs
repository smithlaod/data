﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PlaneGame
{
    class SingleFactory
    {
        private static SingleFactory _single = null;
        private SingleFactory() {
        }

        public Background background { set; get; }
        public Hero hero { set; get; }
        public List<LittleEnemyPlane> LittleEnemyPlaneList = new List<LittleEnemyPlane>(); 
        public List<HeroBullet> BulletList = new List<HeroBullet>();
        public List<BigEnemyPlane> bigEnemyList = new List<BigEnemyPlane>();


        public static SingleFactory GetSingle() {
            if (_single == null)
            {
                _single =  new SingleFactory();
            }
            return _single;
        }

        public void AddObject(GameObject gameObject) {
            if (gameObject is Background)
            {
                background = gameObject as Background;
            }
            else if (gameObject is Hero)
            {
                hero = gameObject as Hero;
            }
            else if (gameObject is HeroBullet)
            {
                BulletList.Add(gameObject as HeroBullet);
            }
            else if (gameObject is LittleEnemyPlane) {
                LittleEnemyPlaneList.Add(gameObject as LittleEnemyPlane);
            }
        }

        public void AddObject(List<LittleEnemyPlane> gameObjects) {
            if (gameObjects.Count > 0 && gameObjects[0] is LittleEnemyPlane)
            {
                this.LittleEnemyPlaneList = gameObjects;
            }
        }

        public void AddObject(List<BigEnemyPlane> gameObjects) {
            if (gameObjects.Count > 0 && gameObjects[0] is BigEnemyPlane)
            {
                this.bigEnemyList = gameObjects;
            }
        }

        public void Shoot() {
            AddObject(new HeroBullet(hero, hero.X + 7, hero.Y + 25, 15, 1));
            AddObject(new HeroBullet(hero, hero.X + 37, hero.Y + 25, 15, 1));
            SoundPlayer shoot = new SoundPlayer(@"C:\Users\dsz12\source\repos\TestApp\PlaneGame\Resources\shoot-[AudioTrimmer.com].wav");
            shoot.Play();

            shoot = null;
        }

        // 目前只能判定直弹
        public void IsEnemyGetHit() {
            if (BulletList.Count > 0)
            {
                for(int i = 0; i < BulletList.Count; i++)
                {
                    var hb = BulletList[i];
                    for (int j = 0; j < LittleEnemyPlaneList.Count; j++) {
                        var enemyPlane = LittleEnemyPlaneList[j];
                        if (enemyPlane != null && hb.X > enemyPlane.X && hb.X < enemyPlane.X + enemyPlane.Width
                                 && hb.Y <= enemyPlane.Y + enemyPlane.Height && hb.Y > enemyPlane.Y)
                        {
                            enemyPlane.Life -= hb.power;
                            BulletList.Remove(hb);
                        }
                    }
                    for (int k = 0; k < bigEnemyList.Count; k++)
                    {
                        var enemyPlane = bigEnemyList[k];
                        if (enemyPlane != null && hb.X > enemyPlane.X && hb.X < enemyPlane.X + enemyPlane.Width
                                 && hb.Y <= enemyPlane.Y + enemyPlane.Height && hb.Y > enemyPlane.Y)
                        {
                            enemyPlane.Life -= hb.power;
                            BulletList.Remove(hb);
                        }
                    }
                }
            }
        }

        // 敌机坠毁输出列表数
        private void  isEnemyDead (Graphics g) {
            for (int j = 0; j < LittleEnemyPlaneList.Count; j++)
            {
                LittleEnemyPlane enemyPlane = LittleEnemyPlaneList[j];
                if (null != enemyPlane && !enemyPlane.shouldBeNull)
                {
                    enemyPlane.Draw(g);
                }
                else
                {
                    LittleEnemyPlaneList.Remove(enemyPlane);
                }
            }
            for (int j = 0; j < bigEnemyList.Count; j++)
            {
                var enemyPlane = bigEnemyList[j];
                if (null != enemyPlane && !enemyPlane.shouldBeNull)
                {
                    enemyPlane.Draw(g);
                }
                else
                {
                    bigEnemyList.RemoveAt(j);
                }
            }
        }

        // 超出范围给个输出
        public void OutThenSolve(Graphics g) {
            for (int i = 0; i < LittleEnemyPlaneList.Count; i++)
            {
                if (LittleEnemyPlaneList[i].isOut)
                {
                    LittleEnemyPlaneList.RemoveAt(i);
                }
            }
            for (int i = 0; i < bigEnemyList.Count; i++)
            {
                if (bigEnemyList[i].isOut)
                {
                    bigEnemyList.RemoveAt(i);
                }
            }
            for (int j = 0; j < BulletList.Count; j++)
            {
                if (BulletList[j].isOut)
                {
                    BulletList.RemoveAt(j);
                }
                else {
                    BulletList[j].Draw(g);
                }
            }
            
        }

        /// <summary>
        /// 每当子弹超过合理位置时，赋一个定值，进行判断，若为此值，则进行回收
        /// </summary>
        /// <param name="g"></param>
        public void Draw(Graphics g) {
            background.Draw(g);
            hero.Draw(g);

            IsEnemyGetHit();
            isEnemyDead(g);

            OutThenSolve(g);
        }
    }
}
 