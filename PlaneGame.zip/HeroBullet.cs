﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PlaneGame.Properties;

namespace PlaneGame
{
    class HeroBullet:BulletFather
    {
        static Image heroBullet = Resources.bullet1;
        public HeroBullet(PlaneFather plane, int x, int y, int speed, int power)
                : base (plane, heroBullet, x, y, speed, power) {
            isOut = false;
        }

        public override void Draw(Graphics g)
        {
            Y -= Speed;
            if (this.Y > max_height)
            {
                this.Y = OUT_WINDOW;
            }
            if (Y < 0)
            {
                Y = this.Y = OUT_WINDOW;
            }
            isOut = this.Y == OUT_WINDOW ? true : false;
            g.DrawImage(heroBullet, this.X, this.Y, Width - 4, Height - 8);
        }

        public override void move(Direction dir) {
            switch (dir)
            {
                case Direction.UP:
                    this.Y += Speed;
                    break;
                case Direction.DOWN:
                    this.Y -= Speed;
                    break;

                case Direction.LEFT:
                    this.X += Speed;
                    break;
                case Direction.RIGHT:
                    this.X += Speed;
                    break;
            }
            //判断对象是否超出窗体 超出时应去除
            if (this.Y > max_height)
            {
                this.Y = OUT_WINDOW;
            }
            if (Y < 0) { 
                Y = this.Y = OUT_WINDOW;
            }
            isOut = this.Y == OUT_WINDOW ? true : false;
        }

        public override void Shoot(MouseEventArgs e)
        {
            throw new NotImplementedException();
        }
    }
}
