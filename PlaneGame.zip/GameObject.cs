﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlaneGame
{
    
    enum Direction
    {
        UP, DOWN, LEFT, RIGHT
    }

    abstract class GameObject
    {
        public const int max_width = 480;
        public const int max_height = 720;
        public const int init_bg_pos = -720;
        public int Life { set; get; }
        public int X { set; get; }
        public int Y { set; get; }
        public int Height { set; get; }
        public int Width { set; get; }
        public int Speed { set; get; }

        public Direction direction { set; get; }

        public GameObject(int x, int y, int width, int height, Direction dir, int speed, int life) {
            X = x;
            Y = y;
            Width = width;
            Height = height;
            Life = life;
            direction = dir;
            Speed = speed;
        }

        public abstract void Draw(Graphics g);
        public Rectangle GetRectangle() {
            return new Rectangle(this.X, this.Y, this.Width, this.Height);
        }

        public virtual void move(Direction dir) {
            switch (dir) {
                case Direction.UP:
                    this.Y += Speed;
                    break;
                case Direction.DOWN:
                    this.Y -= Speed;
                    break;

                case Direction.LEFT:
                    this.X += Speed;
                    break;
                case Direction.RIGHT:
                    this.X += Speed;
                    break;
            }

            //判断对象是否超出窗体
            if (this.X < 0) {
                X = 0;
            }
            if (this.X + this.Width > max_width) {
                this.X = max_width - this.Width;
            }
            if (this.Y > max_height) {
                this.Y = max_height;
            }
            if (this.Y - this.Height < 0) {
                this.Y = this.Height;
            }
        }
    }
}
