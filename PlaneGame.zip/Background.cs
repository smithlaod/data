﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PlaneGame.Properties;
namespace PlaneGame
{
    class Background : GameObject
    {
        private static Image imgBG = Resources.background;

        public Background(int x, int y, int speed) : base(x, y, imgBG.Width, imgBG.Height, Direction.DOWN, speed, -1) {
        }
        public override void Draw(Graphics g)
        {
            this.Y += this.Speed;
            if (this.Y == 0) {
                this.Y = init_bg_pos;    
            }

            g.DrawImage(imgBG, this.X, this.Y);
        }
    }
}
