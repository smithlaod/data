﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PlaneGame
{
    /// <summary>
    /// 子弹父类，核心指标为速度，威力，方向，使用List存储
    /// 要确定
    /// </summary>
    abstract class BulletFather : GameObject
    {
        public const int OUT_WINDOW = max_height + 200;
        public bool isOut { set; get; }
        public int power { set; get; }

        public BulletFather(PlaneFather plane ,Image bullet, int x, int y, int speed, int power)
                : base(x , y, bullet.Width, bullet.Height, plane.direction, speed, -1) {
            this.power = power;
        }

        public abstract void Shoot(MouseEventArgs e);
    }
}
