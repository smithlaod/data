﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using PlaneGame.Properties;

namespace PlaneGame
{
    class BigEnemyPlane : EnemyFather
    {
        private const int _SPEED = 1;
        private const int _LIFE = 5;

        public BigEnemyPlane(int x, int y, Direction dir) : base(
                   () => {
                       Dictionary<string, List<Image>> animation = new Dictionary<string, List<Image>>();
                       List<Image> dieAnima = new List<Image>() { Resources.enemy2_down1, Resources.enemy2_down2,
                                                                                Resources.enemy2_down3, Resources.enemy2_down4};
                       animation.Add("die", dieAnima);
                       return animation;
                   }, Resources.enemy2, x, y, dir, _SPEED, _LIFE)
        { }

        private static void _Die()
        {
            SoundPlayer sp = new SoundPlayer(@"C:\Users\dsz12\source\repos\TestApp\PlaneGame\Resources\die-[AudioTrimmer.com].wav");

            sp.Play();
            sp = null;
        }

        /// <summary>
        /// 在这里设置敌机飞行轨道
        /// </summary>
        /// <param name="g"></param>
        public override void Draw(Graphics g)
        {
            isDead = Life <= 0 ? true : false;
            isOut = Y > max_height;

            if (isDead)
            {
                Task task = new Task(() => { _Die(); });

                task.Start();

                if (index / 5 < 4)
                {
                    Speed = Speed <= 0 ? 0 : Speed - 1;
                    g.DrawImage(DieAnima[index / 5], X, Y, DieAnima[index / 5].Width, DieAnima[index / 5].Height);
                    index++;
                }
                else
                {
                    shouldBeNull = true;
                }
            }
            else
            {
                g.DrawImage(enemyPlane, X, Y, enemyPlane.Width, enemyPlane.Height);
                Y += Speed;
            }
        }

    }
}/*
private void dieAnima(Graphics g)
        {
            Image[] dieImages = { Resources.enemy2_down1, Resources.enemy2_down2, Resources.enemy2_down3, Resources.enemy2_down4 };

            if (index / 4 < 4)
            {
                g.DrawImage(dieImages[index++ / 4], X, Y);
            }
            else
            {
                shouldBeNull = true;
            }
        }
     public override void Draw(Graphics g)
        {
            if (!isDie)
            {
                g.DrawImage(bigEnemyPlane, X, Y, bigEnemyPlane.Width, bigEnemyPlane.Height);
            }
            else
            {
                //给一个坠机的动感
                Speed = Speed <= 0 ? 0 : Speed - 1;
                dieAnima(g);
            }

            this.Y += this.Speed;
            isDie = this.Life <= 0;
            isOut = Y + Height > max_height || X + Width > max_width;
        }
 */
