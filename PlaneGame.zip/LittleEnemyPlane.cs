﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using PlaneGame.Properties;

namespace PlaneGame
{
    /// <summary>
    /// 生成最小的小敌机
    /// </summary>
    class LittleEnemyPlane : EnemyFather
    {
        private const int _SPEED = 1;
        private const int _LIFE = 1;

        /// <summary>
        /// 初始化时直接给上生命和速度
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        public LittleEnemyPlane(int x, int y, Direction dir ) : base (
                   ()=>{
                    Dictionary<string, List<Image>> animation = new Dictionary<string, List<Image>>();
                    List<Image> dieAnima = new List<Image>() { Resources.enemy1_down1, Resources.enemy1_down2,
                                                                                Resources.enemy1_down3, Resources.enemy1_down4};
                    animation.Add("die", dieAnima);
                    return animation;
        }, Resources.enemy1, x, y, dir, _SPEED, _LIFE) { }

        private static void _Die() {
            SoundPlayer sp = new SoundPlayer(@"C:\Users\dsz12\source\repos\TestApp\PlaneGame\Resources\die-[AudioTrimmer.com].wav");

            sp.Play();
            sp = null;
        }
        public override void Draw(Graphics g)
        {
            isDead = Life <= 0 ? true : false;
            isOut = Y > max_height;
            shouldBeNull = index / 5 < 4 ? false : true;

            if (isDead)
            {
                //Task task = new Task(()=>{ _Die(); });

                //task.Start();

                if (index / 5 < 4)
                {
                    Speed = Speed <= 0 ? 0 : Speed - 1;
                    g.DrawImage(DieAnima[index / 5], X, Y, DieAnima[index / 5].Width, DieAnima[index / 5].Height);
                    index++;
                }
            }
            else
            {
                g.DrawImage(enemyPlane, X, Y, enemyPlane.Width, enemyPlane.Height);
                Y += Speed;
            }
        }
    }
}
